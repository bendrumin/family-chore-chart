# CSS Consolidation Plan
**Goal:** Reduce from 4 CSS files to 2 (or 1)

## Current State (4 files - 422KB)
```
1. mobile-chore-modal-integrated.css (16KB) - Mobile modal specific
2. style.css (385KB) - Main styles + our new enhancements
3. clean-ui.css (5.5KB) - Minor UI refinements
4. ui-enhancements.css (16KB) - Quick actions modal
```

## Recommended: 2-File Strategy

### Keep Separate:
✅ **style.css** - Main styles (merge in clean-ui + ui-enhancements)
✅ **mobile-chore-modal-integrated.css** - Keep separate (mobile-specific context)

### Why Keep Mobile Modal Separate?
- Only loads styles needed for mobile modal feature
- Easier to conditionally load/modify
- Clear separation of concerns
- Only 16KB

### Result:
- **2 files** instead of 4
- **~390KB total** (vs 422KB = 7% reduction)
- **50% fewer HTTP requests** for CSS
- **Single source of truth** for main styles

## Alternative: 1-File Strategy (Most Aggressive)

Merge EVERYTHING into style.css:
- **1 file** - 400KB
- **75% fewer HTTP requests**
- Ultimate simplicity
- Loses modularity

**Tradeoff:** Mobile modal styles always load (even on desktop)

## What I Recommend: **Option 2 (Two Files)**

**Merge into style.css:**
1. ✅ clean-ui.css (5.5KB) - All content
2. ✅ ui-enhancements.css (16KB) - Quick actions modal

**Keep Separate:**
1. ✅ mobile-chore-modal-integrated.css (16KB) - Mobile feature

**Benefits:**
- 50% fewer CSS files
- All main UI in one place
- Mobile modal stays modular
- Easy rollback if needed
- Best balance of performance + maintainability
